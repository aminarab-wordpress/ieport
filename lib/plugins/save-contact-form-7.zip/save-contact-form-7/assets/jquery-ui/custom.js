/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 
 

jQuery(document).ready(function(){
    
    //setTimeout(function(){jQuery(".dataTables_wrapper .dataTables_filter input").attr("placeholder","Search Here");},1000);
 jQuery(".dataTables_wrapper .dataTables_filter input").attr("placeholder","Search Here");
 
});