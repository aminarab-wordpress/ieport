<?php

/*
 * Plugin Name: Event Management Plugin 
 * Plugin URI: https://github.com/aminarab
 * Description: Events Management
 * Version: 1.0.0
 * Author: Amin Arab
 * Author URI: https://www.linkedin.com/in/amin-arab-a653b13a/
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: event_d
 * Domain Path: /languages
 */
class wp_event_entrypoint
{

    // properties
    private $wp_event_configs = array();

    // magic function (triggered on initialization)
    public function __construct()
    {
        add_action('init', array(
            $this,
            'set_event_configurations'
        )); // sets the default trading hour days (used by the content type)
        add_action('init', array(
            $this,
            'register_event_content_type'
        )); // register event content type
        add_action('add_meta_boxes', array(
            $this,
            'add_event_meta_boxes'
        )); // add meta boxes
        add_action('save_post_wp_events', array(
            $this,
            'save_event'
        )); // save event
        add_action('admin_enqueue_scripts', array(
            $this,
            'enqueue_admin_scripts_and_styles'
        )); // admin scripts and styles
        add_action('wp_enqueue_scripts', array(
            $this,
            'enqueue_public_scripts_and_styles'
        )); // public scripts and styles
        add_action('plugins_loaded', array(
            $this,
            'load_po_module'
        )); // load the required language file according to selected languages in wp-config.php
        add_filter('the_content', array(
            $this,
            'prepend_event_meta_to_content'
        )); // gets our meta data and dispayed it before the content
        add_filter('single_template', array(
            $this,
            'single_template_layout'
        ));// Filter the single_template with our custom function
        add_filter('archive_template', array(
            $this,
            'archive_template_layout'
        ));// Filter the single_template with our custom function
        register_activation_hook(__FILE__, array(
            $this,
            'plugin_activate'
        )); // activate hook
        register_deactivation_hook(__FILE__, array(
            $this,
            'plugin_deactivate'
        )); // deactivate hook
    }

    // set the default trading hour days (used in our admin backend)
    public function set_event_configurations()
    {
    	$this->pageTemplates = array(
			'archive-list',
			'archive-grid',
			'single-simple'
		);
    }

    // register the event content type
    public function register_event_content_type()
    {
        // Labels for post type
        $labels = array(
            'name' => __( 'Event', 'event_d' ),
            'singular_name' => __( 'Event', 'event_d' ),
            'menu_name' => __( 'Events', 'event_d' ),
            'name_admin_bar' => __( 'event', 'event_d' ),
            'add_new' => __( 'Add New', 'event_d' ),
            'add_new_item' => __( 'Add New Event', 'event_d' ),
            'new_item' => __( 'New Event', 'event_d' ),
            'edit_item' => __( 'Edit Event', 'event_d' ),
            'view_item' => __( 'View Event', 'event_d' ),
            'all_items' => __( 'All Events', 'event_d' ),
            'search_items' => __( 'Search Events', 'event_d' ),
            'parent_item_colon' => __( 'Parent Event:', 'event_d' ),
            'not_found' => __( 'No events found.', 'event_d' ),
            'not_found_in_trash' => __( 'No events found in Trash.', 'event_d' )
        );
        // arguments for post type
        $args = array(
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_nav' => true,
            'query_var' => true,
            'hierarchical' => false,
            'supports' => array(
                'title',
                'thumbnail',
                'editor'
            ),
            'has_archive' => true,
            'menu_position' => 20,
            'show_in_admin_bar' => true,
            'menu_icon' => 'dashicons-lightbulb',
            'rewrite' => array(
                'slug' => 'events',
                'with_front' => 'true'
            )
        );
        // register post type
        register_post_type('wp_events', $args);
    }


    function single_template_layout($single) {
        
        global $post;
        
        /* Checks for single template by post type */
        if ( $post->post_type == 'wp_events' ) {
            if ( file_exists( dirname(plugin_dir_path( __FILE__ )) .'/'. dirname(plugin_basename(__FILE__)) . '/single-event.php' ) ) {
                return dirname(plugin_dir_path( __FILE__ )) .'/'. dirname(plugin_basename(__FILE__)) . '/single-event.php';
            }
        }
        
        return $single;
        
    }
    
    function archive_template_layout($archive) {
        
        global $post;
        
        
        
        /* Checks for single template by post type */
        if ( $post->post_type == 'wp_events' ) {
            if ( file_exists( dirname(plugin_dir_path( __FILE__ )) .'/'. dirname(plugin_basename(__FILE__)) . '/'.$this->pageTemplates[$GLOBALS['redux_demo']['${L_name}-archive-opt-radio']].'.php' ) ) {
                return dirname(plugin_dir_path( __FILE__ )) .'/'. dirname(plugin_basename(__FILE__)) . '/'.$this->pageTemplates[$GLOBALS['redux_demo']['${L_name}-archive-opt-radio']].'.php';
            }
        }
        
        return $single;
        
    }

    // adding meta boxes for the event content type*/
    public function add_event_meta_boxes()
    {
        add_meta_box('wp_event_meta_box', // id
        __( 'MetaBox Event Information', 'event_d' ), // name
        array(
            $this,
            'event_meta_box_display'
        ), // display function
        'wp_events', // post type
        'normal', // event
        'default' // priority
        );
    }

    // display function used for our custom event meta box*/
    public function event_meta_box_display($post)
    {

        // set nonce field
        wp_nonce_field('wp_event_nonce', 'wp_event_nonce_field');
        ?>
<div class="field-container">
			<?php
        // before main form elementst hook
        do_action('wp_event_admin_form_start');
        ?>
    <div class="row">
		<div class="col-xs-12">
			<div class="field">
				<label for="wp_event_name"><?php echo __( 'name', 'event_d' ); ?> : </label>
				<input type="text" name="wp_event_name"  class="regular-text" value="<?php echo get_post_meta($post->ID, 'wp_event_name', true); ?>"  />
			</div>
			<div class="field">
				<label for="wp_event_description"><?php echo __( 'description', 'event_d' ); ?> : </label>
				<textarea rows="5" name="wp_event_description"  class="large-text" ><?php echo get_post_meta($post->ID, 'wp_event_description', true); ?></textarea>
			</div>
		</div>
	</div>
    
		<?php
        // after main form elementst hook
        do_action('wp_event_admin_form_end');
        ?>
		</div>
<?php
    }

    // triggered on activation of the plugin (called only once)
    public function plugin_activate()
    {

        // call our custom content type function
        $this->register_event_content_type();
        // flush permalinks
        flush_rewrite_rules();
    }

    // trigered on deactivation of the plugin (called only once)
    public function plugin_deactivate()
    {
        // flush permalinks
        flush_rewrite_rules();
    }

    public function load_po_module()
    {
        load_plugin_textdomain('wp_event_plugin', false, dirname(plugin_basename(__FILE__)) . '/');
    }

    // append our additional meta data for the event before the main content (when viewing a single event)
    public function prepend_event_meta_to_content($content)
    {
        global $post, $post_type;

        // display meta only on our events (and if its a single event)
        if ($post_type == 'wp_events' && is_singular('wp_events')) {


            // display
            $html = '';

            $html .= '<section class="meta-data">';

            // hook for outputting additional meta data (at the start of the form)
            do_action('wp_event_meta_data_output_start', $post->ID);

            $html .= '<p>';
            			//name
			if(! empty(get_post_meta($post->ID, 'wp_event_name', true))){
				$html .= '<b>'.__( 'name', 'event_d' ).'</b>' . get_post_meta($post->ID, 'wp_event_name', true) . '</br>';
			}
			//description
			if(! empty(get_post_meta($post->ID, 'wp_event_description', true))){
				$html .= '<b>'.__( 'description', 'event_d' ).'</b>' . get_post_meta($post->ID, 'wp_event_description', true) . '</br>';
			}

            $html .= '</p>';
            
            // hook for outputting additional meta data (at the end of the form)
            do_action('wp_event_meta_data_output_end', $post->ID);

            $html .= '</section>';
            $html .= $content;

            return $html;
        } else {
            return $content;
        }
    }

    // main function for displaying events (used for our shortcodes and widgets)
    public function get_events_output($arguments = "")
    {

        // default args
        $default_args = array(
            'event_id' => '',
            'number_of_events' => - 1
        );

        // update default args if we passed in new args
        if (! empty($arguments) && is_array($arguments)) {
            // go through each supplied argument
            foreach ($arguments as $arg_key => $arg_val) {
                // if this argument exists in our default argument, update its value
                if (array_key_exists($arg_key, $default_args)) {
                    $default_args[$arg_key] = $arg_val;
                }
            }
        }

        // output
        $html = '';
        $event_args = array(
            'post_type' => 'wp_events',
            'posts_per_page' => $default_args['number_of_events'],
            'post_status' => 'publish'
        );
        // if we passed in a single event to display
        if (! empty($default_args['event_id'])) {
            $event_args['include'] = $default_args['event_id'];
        }

        $events = get_posts($event_args);
        // if we have events
        if ($events) {
            $html .= '<article class="event_list cf">';
            // foreach event
            foreach ($events as $event) {
                $html .= '<section class="event">';
                // collect event data
                $wp_event_id = $event->ID;
                $wp_event_title = get_the_title($wp_event_id);
                $wp_event_thumbnail = get_the_post_thumbnail($wp_event_id, 'thumbnail');
                //$wp_event_content = apply_filters('the_content', $event->post_content);
                $wp_event_content = $this->prepend_event_meta_to_content($event->post_content);
                if (! empty($wp_event_content)) {
                    $wp_event_content = strip_shortcodes(wp_trim_words($wp_event_content, 40, '...'));
                }
                $wp_event_permalink = get_permalink($wp_event_id);
				
				
				
                // title
                $html .= '<h2 class="title">';
                $html .= '<a href="' . $wp_event_permalink . '" title="view event">';
                $html .= $wp_event_title;
                $html .= '</a>';
                $html .= '</h2>';

                // image & content
                if (! empty($wp_event_thumbnail) || ! empty($wp_event_content)) {

                    $html .= '<p class="image_content">';
                    if (! empty($wp_event_thumbnail)) {
                        $html .= $wp_event_thumbnail;
                    }
                    if (! empty($wp_event_content)) {
                        $html .= $wp_event_content;
                    }

                    $html .= '</p>';
                }
 
               $html .= '<p>';
               			//name
			if(! empty(get_post_meta($post->ID, 'wp_event_name', true))){
				$html .= '<b>'.__( 'name', 'event_d' ).'</b>' . get_post_meta($post->ID, 'wp_event_name', true) . '</br>';
			}
			//description
			if(! empty(get_post_meta($post->ID, 'wp_event_description', true))){
				$html .= '<b>'.__( 'description', 'event_d' ).'</b>' . get_post_meta($post->ID, 'wp_event_description', true) . '</br>';
			}

               $html .= '</p>';
                
                // readmore
                $html .= '<a class="link" href="' . $wp_event_permalink . '" title="view event">View event</a>';
                $html .= '</section>';
            }
            $html .= '</article>';
            $html .= '<div class="cf"></div>';
        }

        return $html;
    }

    // triggered when adding or editing a event
    public function save_event($post_id)
    {

        // check for nonce
        if (! isset($_POST['wp_event_nonce_field'])) {
            return $post_id;
        }
        // verify nonce
        if (! wp_verify_nonce($_POST['wp_event_nonce_field'], 'wp_event_nonce')) {
            return $post_id;
        }
        // check for autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return $post_id;
        }
        
				update_post_meta($post_id, 'wp_event_name', isset($_POST['wp_event_name']) ? sanitize_text_field($_POST['wp_event_name']) : '' );
		update_post_meta($post_id, 'wp_event_description', isset($_POST['wp_event_description']) ? sanitize_text_field($_POST['wp_event_description']) : '' );


        // event save hook
        // used so you can hook here and save additional post fields added via 'wp_event_meta_data_output_end' or 'wp_event_meta_data_output_end'
        do_action('wp_event_admin_save', $post_id);
    }

    // enqueus scripts and stles on the back end
    public function enqueue_admin_scripts_and_styles()
    {
        wp_enqueue_style('wp_event_admin_styles', plugin_dir_url(__FILE__) . '/css/event_admin.css');
    }

    // enqueues scripts and styled on the front end
    public function enqueue_public_scripts_and_styles()
    {
        wp_enqueue_style('wp_event_public_styles', plugin_dir_url(__FILE__) . '/css/single.css');
    }
}
$wp_events_entrypoint = new wp_event_entrypoint();
// include shortcodes
include (plugin_dir_path(__FILE__) . 'inc/event_shortcodes.php');
// include widgets
include (plugin_dir_path(__FILE__) . 'inc/event_widget.php');
?>