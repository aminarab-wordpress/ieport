<?php get_header(); the_post(); ?>

<h2 id="post-title"><?php the_title(); ?></h2>

<?php include (TEMPLATEPATH . '/inc/meta.php' ); 
//include (dirname(plugin_dir_path( __FILE__ )) .'/'. dirname(plugin_basename(__FILE__)) . '/inc/meta.php' );
?>
<div id="main-content">

		<div <?php post_class() ?> id="post-<?php the_ID(); ?>">

			<div class="entry">
				
				<?php the_content(); ?>

				<?php wp_link_pages(array('before' => __( 'Pages: ', 'event_d' ), __( 'next_or_number', 'event_d' ) => __( 'number', 'event_d' ))); ?>
				
				<?php the_tags( __( 'Tags: ', 'event_d' ), ', ', ''); ?>

			</div>
			
			<?php edit_post_link(__( 'Edit this entry.', 'event_d' ), '<p>', '</p>'); ?>
			
		</div>

	<?php comments_template(); ?>
	
</div>
	
<?php get_sidebar(); ?>

<?php get_footer(); ?>