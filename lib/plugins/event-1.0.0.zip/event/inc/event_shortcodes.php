<?php
/*
 * Wp event Shortcode
 * A shortcode created to display a event or series of events when used in the editor or other areas
 */

//defines the functionality for the event shortcode
class wp_event_shortcode{
    
    //on initialize
    public function __construct(){
        add_action('init', array($this,'register_event_shortcodes')); //shortcodes
    }
    //event shortcode
    public function register_event_shortcodes(){
        add_shortcode('events_shortcode', array($this,'event_shortcode_output'));
    }
    
    //shortcode display
    public function event_shortcode_output($atts, $content = '', $tag){
        
        //get the global wp_simple_events class
        global $wp_events_entrypoint;
        
        //build default arguments
        $arguments = shortcode_atts(array(
            'event_id' => '',
            'number_of_events' => -1)
            ,$atts,$tag);
        
        //uses the main output function of the event class
        return $wp_events_entrypoint->get_events_output($arguments);
   
    }
}
$wp_event_shortcode = new wp_event_shortcode;
?>