<?php
/*
 * Wp event Widget
 * Defines the widget to be used to showcase single or multiple events
 */
//main widget used for displaying events
class wp_event_widget extends WP_widget{
    
    //initialise widget values
    public function __construct(){
        //set base values for the widget (override parent)
        parent::__construct(
            'wp_event_widget',
            __( 'WP Event Widget', 'event_d' ),
            array('description' => __( 'A widget that displays your events', 'event_d' ))
            );
        add_action('widgets_init',array($this,'register_wp_event_widgets'));
    }
    
    //handles public display of the widget
    //$args - arguments set by the widget area, $instance - saved values
    public function widget( $args, $instance ) {
        
        //get wp_events_entrypoint class (as it builds out output)
        global $wp_events_entrypoint;
        
        //pass any arguments if we have any from the widget
        $arguments = array();
        //if we specify a event
        
        //if we specify a single event
        if($instance['event_id'] != 'default'){
            $arguments['event_id'] = $instance['event_id'];
        }
        //if we specify a number of events
        if($instance['number_of_events'] != 'default'){
            $arguments['number_of_events'] = $instance['number_of_events'];
        }
        
        //get the output
        $html = '';
        
        $html .= $args['before_widget'];
        $html .= $args['before_title'];
        $html .= 'events';
        $html .= $args['after_title'];
        //uses the main output function of the event class
        $html .= $wp_events_entrypoint->get_events_output($arguments);
        $html .= $args['after_widget'];
        
        echo $html;
    }
    
    //handles the back-end admin of the widget
    //$instance - saved values for the form
    public function form($instance){
        //collect variables
        $event_id = (isset($instance['event_id']) ? $instance['event_id'] : 'default');
        $number_of_events = (isset($instance['number_of_events']) ? $instance['number_of_events'] : 5);
        
        ?>
		<p><?php echo __( 'Select your options below', 'event_d' ); ?></p>
		<p>
			<select class="widefat" name="<?php echo $this->get_field_name('event_id'); ?>" id="<?php echo $this->get_field_id('event_id'); ?>" value="<?php echo $event_id; ?>">
				<option value="default">All events</option>
				<?php
				$args = array(
					'posts_per_page'	=> -1,
					'post_type'			=> 'wp_events'
				);
				$events = get_posts($args);
				if($events){
					foreach($events as $event){
						if($event->ID == $event_id){
							echo '<option selected value="' . $event->ID . '">' . get_the_title($event->ID) . '</option>';
						}else{
							echo '<option value="' . $event->ID . '">' . get_the_title($event->ID) . '</option>';
						}
					}
				}
				?>
			</select>
		</p>
		<p>
			<small>If you want to display multiple events select how many below</small><br/>
			<label for="<?php echo $this->get_field_id('number_of_events'); ?>">Number of events</label>
			<select class="widefat" name="<?php echo $this->get_field_name('number_of_events'); ?>" id="<?php echo $this->get_field_id('number_of_events'); ?>" value="<?php echo $number_of_events; ?>">
				<option value="default">All</option>
			</select>
		</p>
		<?php
	}
	
	//handles updating the widget 
	//$new_instance - new values, $old_instance - old saved values
	public function update($new_instance, $old_instance){
		$instance = array();
		
		$instance['event_id'] = $new_instance['event_id'];
		$instance['number_of_events'] = $new_instance['number_of_events'];
		
		return $instance;
	}
	
	//registers our widget for use
	public function register_wp_event_widgets(){
		register_widget('wp_event_widget');
	}
}
$wp_event_widget = new wp_event_widget;
?>